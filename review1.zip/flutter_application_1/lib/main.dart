import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Text(widget.title),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            // Lingkaran bagian atas dari salib
            buildCircle(Colors.blue),
            const SizedBox(height: 20), // Jarak antar lingkaran
            
            // Baris tengah dari salib
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                buildSquare(Colors.red), // Kotak kiri dari salib
                const SizedBox(width: 20), // Jarak antar kotak
                buildSquare(Colors.green), // Kotak tengah dari salib
                const SizedBox(width: 20), // Jarak antar kotak
                buildSquare(Colors.orange), // Kotak kanan dari salib
              ],
            ),
            const SizedBox(height: 20), // Jarak antar lingkaran

            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                buildSquare(Colors.red), // Kotak kiri dari salib
                const SizedBox(width: 20), // Jarak antar kotak
                

              ],
            ),

          
          ],
        ),
      ),
    );
  }

  // Fungsi pembantu untuk membuat persegi
  Widget buildSquare(Color color) {
    return Container(
      width: 100,
      height: 100,
      color: color,
    );
  }

  // Fungsi pembantu untuk membuat lingkaran
  Widget buildCircle(Color color) {
    return Container(
      width: 100,
      height: 100,
      decoration: BoxDecoration(
        color: color,
        shape: BoxShape.circle,
      ),
    );
  }
}
